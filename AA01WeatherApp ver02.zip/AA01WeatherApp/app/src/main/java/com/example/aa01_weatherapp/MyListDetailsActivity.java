package com.example.aa01_weatherapp;

import android.os.Parcel;
import android.os.Parcelable;

public class MyListDetailsActivity implements Parcelable {

    private String name;
    private int zipCode, temp;
    private double low, high, current, time;
    private String icon;
    private String condition;
    private static boolean units; //farenheit

    public MyListDetailsActivity(String name, int zipCode, double low, double high, double current, String icon) {
        this.name = name;
        this.zipCode = zipCode;
        this.low = low;
        this.high = high;
        this.current = current;
        this.icon = icon;
    }

    public double getTime() {
        return time;
    }

    public int getTemp() {
        return temp;
    }

    public double getCurrent() {
        return current;
    }

    public String getName() {
        return name;
    }

    public double getHigh() {
        return high;
    }

    public double getLow() {
        return low;
    }

    public String getIcon() {
        return icon;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.name);
        parcel.writeInt(this.zipCode);
        parcel.writeDouble(this.low);
        parcel.writeDouble(this.high);
        parcel.writeDouble(this.current);
        parcel.writeString(this.icon);
        parcel.writeString(this.condition);
    }

    public static final Parcelable.Creator<MyListDetailsActivity> CREATOR = new Parcelable.Creator<MyListDetailsActivity>() {

        @Override
        public MyListDetailsActivity createFromParcel(Parcel parcel) {
            return null;
        }

        @Override
        public MyListDetailsActivity[] newArray(int i) {
            return new MyListDetailsActivity[0];
        }
    };
}
