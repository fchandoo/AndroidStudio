package com.example.aa01_weatherapp;

public class SecondActivity {

}
