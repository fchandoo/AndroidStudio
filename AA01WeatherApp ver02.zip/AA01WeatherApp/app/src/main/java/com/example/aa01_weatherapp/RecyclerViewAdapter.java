package com.example.aa01_weatherapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {
        //adapter working with holder
        private final ArrayList<MyListDetailsActivity> mv_data;

    public RecyclerViewAdapter(ArrayList<MyListDetailsActivity> mv_data) {
        this.mv_data = mv_data;
    }

    //Activity cv_activity;
        public static class MyViewHolder extends RecyclerView.ViewHolder {
            private final TextView cv_cityName, cv_time, cv_Temp;

            public MyViewHolder(View view) {
                super(view);
                // Define click listener for the ViewHolder's View
                cv_cityName = view.findViewById(R.id.vv_cityName);
                cv_time = view.findViewById(R.id.vv_time);
                cv_Temp = view.findViewById(R.id.vv_Temp);
            }
        }


        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Create a new view, which defines the UI of the list item
            View lv_view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.recyclerview, parent, false);
            return new MyViewHolder(lv_view);
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(RecyclerViewAdapter.MyViewHolder holder, int position) {
            holder.cv_cityName.setText(mv_data.get(position).getName());
            holder.cv_Temp.setText( mv_data.get(position).getTemp());
            holder.cv_time.setText((int) mv_data.get(position).getTime());
            //enter the get price


            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), "position :" + holder.getLayoutPosition()
                            + "text :" + holder.cv_cityName.getText(), Toast.LENGTH_SHORT).show();
                }
            });
        }


        @Override
        public int getItemCount() {
            return mv_data.size();
        }
    }


