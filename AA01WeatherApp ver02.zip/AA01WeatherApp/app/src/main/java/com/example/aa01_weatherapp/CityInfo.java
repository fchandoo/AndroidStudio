package com.example.aa01_weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.aa01_weatherapp.databinding.ActivityCityBinding;

import java.util.ArrayList;
import android.os.Bundle;


public class CityInfo extends AppCompatActivity {
    ArrayList<MyListDetailsActivity> lv_city;
    RecyclerViewAdapter lv_adapter;
    ActivityCityBinding cityBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cityBinding= ActivityCityBinding.inflate(getLayoutInflater());
        setContentView(cityBinding.getRoot());
        RecyclerView lv_recyclerView = findViewById(R.id.vv_rvList);
        lv_recyclerView.setLayoutManager(new LinearLayoutManager(this));

        if(getIntent() != null){
            Bundle extra = getIntent().getExtras();
            MyListDetailsActivity weather = (MyListDetailsActivity) getIntent().getParcelableExtra("Weather");
            lv_city= new ArrayList<>();
            lv_city.add(weather);
            cityBinding.CityName.setText(weather.getName());
            cityBinding.condition.setText(weather.getIcon()); 
            
            //cityBinding.con

        }

        lv_adapter = new RecyclerViewAdapter(lv_city);
        lv_recyclerView.setAdapter(lv_adapter);

    }
}
