package com.example.aa01_weatherapp;

import android.content.Context;
import android.os.Bundle;
import android.view.View;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import  com.example.aa01_weatherapp.databinding.JsonActivityBinding;


import androidx.appcompat.app.AppCompatActivity;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;


public class MyJson extends AppCompatActivity {
    private JsonActivityBinding binding;

    final String stringUrl = "https://ziptasticapi.com/48197";
    String json = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = JsonActivityBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        binding.button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Context ctx = MyJson.this;
                        binding.textview.setText("JSON->" + json + "\n\n" + parseJson(json));
                    }
                });
        binding.floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                httpInThread(stringUrl);
            }
        });
    }

    //version 06
    private void httpInThread(String url) {
        new Thread(new Runnable() {
            String result = "HTTPS unable to get";

            @Override
            public void run() {
                // do your stuff
                try {
                    result = downloadUrl(url);
                } catch (IOException e) {
                    binding.textview.setText("Unable to retrieve web page. URL may be invalid.");
                    return;
                }
                runOnUiThread(new Runnable() {
                    public void run() {
                        // do onPostExecute stuff
                        binding.textview.setText(result);
                        json = result;
                    }
                });
            }
        }).start();
    }

    private String downloadUrl(String urlString) throws IOException {
        String result = "Download https error";
        InputStream in = null;
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.connect();
            in = conn.getInputStream();

            StringBuilder stringBuilder = new StringBuilder();
            reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            result = stringBuilder.toString();
        } catch (IOException e) {
        } finally {
            if (in != null)
                try {
                    in.close();
                    reader.close();
                } catch (IOException e) {
                }
        }
        return result;
    }


    private String parseJson(String input) {

        String output = "Error parsing Json";
        JSONParser parser = new JSONParser();
        try {
            JSONObject jsonRootObject = (JSONObject) parser.parse(input);
            JSONArray jsonWeatherArray = (JSONArray) jsonRootObject.get("weather");
            String cond = ((JSONObject) jsonWeatherArray.get(0)).get("main").toString();

            JSONObject jsonMainObject = (JSONObject) jsonRootObject.get("main");
            double temp = Double.parseDouble(jsonMainObject.get("temp").toString());
            String city = jsonRootObject.get("name").toString();
            output = city + " :condition is " + cond + ", at " + String.format("%.2f", (temp - 273.15)) + " celsius";
        } catch (ParseException | JSONException e) {
            e.printStackTrace();
        }
        return output;
    }
}
