package com.example.a10rv2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ObjectInputStream;
import java.util.ArrayList;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.MyViewHolder> {
    //private final ArrayList<String> mv_data01, mv_data02;
    private final ArrayList<MyRecyclerViewData> mv_data;

    public MyRecyclerViewAdapter(ArrayList<MyRecyclerViewData> data) {
        mv_data = data;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final TextView cv_tvmodel;
        public final TextView cv_tvOS, cv_tvPrice;

        public MyViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View
            cv_tvmodel = view.findViewById(R.id.vv_tvmodel);
            cv_tvOS = view.findViewById(R.id.vv_tvOS);
            cv_tvPrice = view.findViewById(R.id.vv_tvPrice);
//// Method 1:
/*            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), "position : " + getLayoutPosition()
                            + " text : " + cv_tvCell.getText(), Toast.LENGTH_SHORT).show();
                }
            });*/
        }
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View lv_view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_row, parent, false);
        return new MyViewHolder(lv_view);

//// Method 2: BETTER then Method 3?
/*        MyViewHolder lv_holder = new MyViewHolder(lv_view);
        lv_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "position : " + lv_holder.getLayoutPosition()
                        + " text : " + lv_holder.cv_tvCell.getText(), Toast.LENGTH_SHORT).show();
            }
        });
        return lv_holder;*/
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyRecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.cv_tvmodel.setText(" "+mv_data.get(position).getModel());
        holder.cv_tvOS.setText(mv_data.get(position).getOS());
        holder.cv_tvPrice.setText("    $"+mv_data.get(position).getPrice());

//// Method 3: itemView is hidden defined
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "position : " + holder.getLayoutPosition()
                        + " text : " + holder.cv_tvmodel.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mv_data.size();
    }
}