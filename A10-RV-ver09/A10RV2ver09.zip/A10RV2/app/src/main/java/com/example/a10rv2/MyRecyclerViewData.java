package com.example.a10rv2;

public class MyRecyclerViewData {
    private String mv_model;
    private String mv_os;
    private int mv_price;

    public MyRecyclerViewData(){
    }

    public MyRecyclerViewData(String model, String os, int price){
        mv_model = model;
        mv_os = os;
        mv_price = price;
    }

    public String getModel(){
        return this.mv_model;
    }

    public String getOS(){
        return this.mv_os;
    }

    public int getPrice(){
        return this.mv_price;
    }

    public void setModel(String model){
        mv_model = model;
    }

    public void setOS(String os){
        mv_os = os;
    }

    public void setPrice(int price){
        mv_price = price;
    }
}

