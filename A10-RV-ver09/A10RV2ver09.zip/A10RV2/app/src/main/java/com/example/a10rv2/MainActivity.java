package com.example.a10rv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Scanner;


public class MainActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    SwipeRefreshLayout cv_refresh;
    ArrayList<MyRecyclerViewData> lv_data;
    MyRecyclerViewAdapter lv_adapter;
    FloatingActionButton fab;
    Scanner fileScanner = new Scanner(this.getResources().openRawResource(R.raw.pad));


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fab = findViewById(R.id.vv_fab);
        RecyclerView lv_recyclerView = findViewById(R.id.vv_rvList);
        cv_refresh = (SwipeRefreshLayout) findViewById(R.id.vv_refresh);
        cv_refresh.setOnRefreshListener(this);
        cv_refresh.setColorSchemeColors(Color.GREEN);
        // ##### small issue
        lv_recyclerView.setLayoutManager(new LinearLayoutManager(this));
        String[] lv_Model = {"iPad", "Xoom", "Playbook", "TouchPad", "Surface"};
        String[] lv_OS = {"iOS", "Android", "BlackBerry", "WebOS", "Windows"};
        int[] lv_Price = {499, 799, 499, 499, 449};

        lv_data = new ArrayList<>();
        for (int i = 0; i < lv_Model.length; i++) {
            lv_data.add(new MyRecyclerViewData(lv_Model[i], lv_OS[i], lv_Price[i]));
        }

        lv_adapter = new MyRecyclerViewAdapter(lv_data);
        lv_recyclerView.setAdapter(lv_adapter);
        lv_recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lv_data.add(1, new MyRecyclerViewData("New Model", "New OS\t", 123));
                lv_adapter.notifyDataSetChanged();


            }

        });
        fab.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                //// HERE
                lv_data.remove(2);
                lv_adapter.notifyDataSetChanged();
                return true;
            }
        });
    }
        @Override
        public void onRefresh() {
            cv_refresh.setRefreshing(true);
            for (int i=0; i < lv_data.size(); i++) {
                lv_data.get(i).setPrice((int) Math.ceil(Math.random()*500+1000));
            }

            lv_adapter.notifyDataSetChanged();
            // This line is important as it explicitly refreshes only once
            // If "true" it implicitly refreshes forever
            cv_refresh.setRefreshing(false);
        }
    }

