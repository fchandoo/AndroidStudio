package com.example.a11_intent;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.a11_intent.databinding.ActivityMainBinding;
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Bundle extras= getIntent().getExtras();
        String lv_str= extras !=null? extras.getString("Back Button"):"From Launch";
        binding.vvTvOut1.setText(lv_str);

        binding.vvBtnTo2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ////Context ctx =  MainActivity.this;
                        // need MainActivity.this since 'this' is new OnclickListener
                        Intent lv_it = new Intent(MainActivity.this, MySecondActivity.class);
                        lv_it.putExtra("StrArg", binding.vvEtIn1.getText().toString());
                        startActivity(lv_it);
                        overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);


                    }
                });
    }
}