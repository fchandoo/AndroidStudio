package com.example.a11_intent;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.a11_intent.databinding.ActivityMySecondBinding;

public class MySecondActivity extends AppCompatActivity {
    private ActivityMySecondBinding binding;

    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_my_second);
            binding= ActivityMySecondBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());
        //info regarding tool bar
        if (getIntent() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            //getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Back to First");

            binding.vvBtnTo1.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent lv_it = new Intent(MySecondActivity.this, MainActivity.class);
                            startActivity(lv_it);
                        }
                    });

            Bundle extras = getIntent().getExtras();
            String lv_str = extras != null ? extras.getString("StrArg") : "Empty";
            binding.vvTvOut2.setText("You Typed - " + lv_str);

        }

            //// HERE https://developer.android.com/guide/navigation/navigation-custom-back
            // This callback will only be called when MyFragment is at least Started.
            OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
                @Override
                public void handleOnBackPressed() {
                    // Handle the back button event
                    //onBackPressed();
                    getSupportActionBar().setTitle("Back");
                    Intent lv_it = new Intent(MySecondActivity.this, MainActivity.class);
                    startActivity(lv_it);
                    lv_it.putExtra("BackButton", "From Second, by nav");
                    startActivity(lv_it);
                    //binding.vvBtnTo1.setText("From Second, by Button");
                }
            };
            getOnBackPressedDispatcher().addCallback(this, callback);
            // The callback can be enabled or disabled here or in handleOnBackPressed()
        }

        @Override
        public boolean onSupportNavigateUp() {
            Intent lv_it = new Intent(MySecondActivity.this, MainActivity.class);
            startActivity(lv_it);
            lv_it.putExtra("method", "button");
            return true;
        }


    // Method 1 android.R.id.home:
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent lv_it = new Intent(MySecondActivity.this, MainActivity.class);
                startActivity(lv_it);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent lv_it = new Intent(MySecondActivity.this, MainActivity.class);
        startActivity(lv_it);
        lv_it.putExtra("method", "button");

    }

    private void cfp_navBack (boolean flag){
        overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
    }
}
